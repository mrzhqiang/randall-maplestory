create table queststatus
(
    queststatusid int unsigned auto_increment
        primary key,
    characterid   int     default 0 not null,
    quest         int(6)  default 0 not null,
    status        tinyint default 0 not null,
    time          int     default 0 not null,
    forfeited     int     default 0 not null,
    customData    varchar(255)      null,
    constraint queststatus_ibfk_1
        foreign key (characterid) references characters (id)
            on delete cascade
)
    charset = utf8;

create index characterid
    on queststatus (characterid);

INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9074, 1, 190000, 0, 1544417418, 0, '0');
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9075, 1, 190001, 0, 1544417418, 0, '0');
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9076, 1, 1031, 2, 1544417450, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9077, 1, 1021, 2, 1544417469, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9078, 1, 1032, 2, 1544417750, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9079, 1, 1033, 2, 1544417756, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9080, 1, 1034, 2, 1544417764, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9081, 1, 1035, 2, 1544417787, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9082, 1, 1036, 2, 1544417798, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9083, 1, 1037, 2, 1544417910, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9084, 1, 1009, 2, 1544417859, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9085, 1, 1010, 2, 1544417863, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9086, 1, 1011, 2, 1544417866, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9087, 1, 1012, 2, 1544417869, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9088, 1, 1013, 2, 1544417873, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9089, 1, 1014, 2, 1544417878, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9090, 1, 1015, 2, 1544417881, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9091, 1, 4760, 2, 1544417888, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9092, 1, 1008, 2, 1544417901, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9093, 1, 1020, 2, 1544417905, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9094, 1, 1038, 2, 1544417920, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9095, 1, 1040, 2, 1544418785, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9096, 1, 1041, 2, 1544418049, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9097, 1, 1039, 2, 1544418008, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9098, 1, 1042, 2, 1544418082, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9099, 1, 1043, 2, 1544418113, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9100, 1, 1044, 2, 1544418140, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9101, 1, 4761, 2, 1544418143, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9102, 1, 1045, 2, 1544418828, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9103, 1, 1048, 2, 1544418151, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9104, 1, 2197, 2, 1544418163, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9105, 1, 2081, 2, 1544418207, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9106, 1, 2080, 2, 1544418271, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9107, 1, 2132, 2, 1544419500, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9108, 1, 2401, 2, 1544419186, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9109, 1, 4762, 2, 1544419198, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9110, 1, 2406, 2, 1544419497, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9111, 1, 2133, 2, 1544419640, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9112, 1, 2134, 2, 1544419820, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9113, 1, 2411, 2, 1544419690, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9114, 1, 2423, 2, 1544425293, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9115, 1, 2428, 2, 1544425305, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9116, 1, 2416, 2, 1544419855, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9117, 1, 2135, 2, 1544425324, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9118, 1, 4763, 2, 1544419842, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9119, 1, 29015, 1, 1544426962, 0, '0');
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9120, 1, 29005, 1, 1544426962, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9121, 1, 27010, 1, 1544426962, 0, '4');
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9122, 1, 28180, 2, 1544504106, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9123, 1, 28181, 2, 1544504839, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9124, 1, 28182, 2, 1544504115, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9125, 1, 28183, 2, 1544504840, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9126, 1, 28184, 2, 1544504841, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9127, 1, 28185, 2, 1544504880, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9128, 1, 28186, 2, 1544504913, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9129, 1, 28187, 2, 1544505075, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9130, 1, 28188, 2, 1544505109, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9131, 1, 28189, 2, 1544505137, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9132, 1, 28190, 2, 1544505156, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9133, 1, 28191, 2, 1544505181, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9134, 1, 28192, 2, 1544505373, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9135, 1, 28193, 2, 1544505404, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9136, 1, 28194, 2, 1544505428, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9137, 1, 28195, 2, 1544505466, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9138, 1, 28196, 2, 1544506086, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9139, 1, 28197, 2, 1544506177, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9140, 1, 28198, 1, 1544506180, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9141, 1, 4764, 2, 1544507046, 0, null);
INSERT INTO ms079.queststatus (queststatusid, characterid, quest, status, time, forfeited, customData) VALUES (9142, 1, 2264, 2, 1544507273, 0, null);