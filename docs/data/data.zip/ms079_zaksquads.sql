create table zaksquads
(
    id       int unsigned auto_increment
        primary key,
    channel  int unsigned           not null,
    leaderid int unsigned default 0 not null,
    status   int unsigned default 0 not null,
    members  int unsigned default 0 not null
)
    charset = utf8;

