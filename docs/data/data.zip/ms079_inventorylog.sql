create table inventorylog
(
    inventorylogid  int unsigned auto_increment
        primary key,
    inventoryitemid int unsigned default 0 not null,
    msg             tinytext               not null,
    constraint inventorylog_ibfk_1
        foreign key (inventoryitemid) references inventoryitems (inventoryitemid)
            on delete cascade
)
    charset = utf8;

create index inventoryitemid
    on inventorylog (inventoryitemid);

