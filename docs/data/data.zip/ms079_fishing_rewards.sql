create table fishing_rewards
(
    itemid     int                     not null,
    chance     int                     not null,
    expiration int          default 0  null,
    name       varchar(255) default '' null
)
    charset = utf8;

