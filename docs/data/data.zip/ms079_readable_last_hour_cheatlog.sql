create definer = root@`%` view readable_last_hour_cheatlog as
select `a`.`name`        AS `accountname`,
       `a`.`id`          AS `accountid`,
       `c`.`name`        AS `name`,
       `c`.`id`          AS `characterid`,
       sum(`cl`.`count`) AS `numrepos`
from ((`ms079`.`cheatlog` `cl` join `ms079`.`characters` `c`)
         join `ms079`.`accounts` `a`)
where ((`cl`.`id` = `c`.`id`) and (`a`.`id` = `c`.`accountid`) and
       (timestampdiff(HOUR, `cl`.`lastoffensetime`, now()) < 1) and (`a`.`banned` = 0))
group by `cl`.`id`
order by sum(`cl`.`count`) desc;

