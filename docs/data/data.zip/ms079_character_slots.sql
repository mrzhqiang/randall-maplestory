create table character_slots
(
    id        int auto_increment
        primary key,
    accid     int default 0 not null,
    worldid   int default 0 not null,
    charslots int default 6 not null
)
    charset = utf8;

INSERT INTO ms079.character_slots (id, accid, worldid, charslots) VALUES (1, 1, 0, 3);