create table blocklogin
(
    account     varchar(255) null,
    blocktime   varchar(255) null,
    unblocktime varchar(255) null,
    ip          varchar(255) null,
    active      varchar(255) null
)
    charset = utf8;

