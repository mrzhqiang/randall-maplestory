create table keymap
(
    id          int auto_increment
        primary key,
    characterid int              default 0 not null,
    `key`       tinyint unsigned default 0 not null,
    type        tinyint unsigned default 0 not null,
    action      int              default 0 not null,
    constraint keymap_ibfk_1
        foreign key (characterid) references characters (id)
            on delete cascade
)
    charset = utf8;

INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (6992, 1, 2, 4, 10);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (6993, 1, 3, 4, 12);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (6994, 1, 4, 4, 13);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (6995, 1, 64, 6, 105);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (6996, 1, 5, 4, 18);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (6997, 1, 65, 6, 106);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (6998, 1, 6, 4, 24);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (6999, 1, 7, 4, 21);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7000, 1, 79, 2, 2000006);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7001, 1, 73, 1, 1002);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7002, 1, 17, 4, 5);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7003, 1, 16, 4, 8);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7004, 1, 19, 4, 4);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7005, 1, 18, 4, 0);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7006, 1, 81, 2, 2120000);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7007, 1, 20, 1, 2001002);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7008, 1, 83, 2, 2000002);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7009, 1, 23, 4, 1);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7010, 1, 25, 4, 19);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7011, 1, 27, 4, 15);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7012, 1, 26, 4, 14);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7013, 1, 29, 5, 52);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7014, 1, 30, 1, 2001005);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7015, 1, 34, 4, 17);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7016, 1, 35, 4, 11);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7017, 1, 38, 4, 20);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7018, 1, 36, 4, 2);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7019, 1, 37, 4, 3);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7020, 1, 43, 4, 9);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7021, 1, 40, 4, 16);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7022, 1, 41, 4, 23);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7023, 1, 46, 4, 6);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7024, 1, 44, 5, 50);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7025, 1, 45, 5, 51);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7026, 1, 50, 4, 7);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7027, 1, 48, 4, 22);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7028, 1, 59, 6, 100);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7029, 1, 57, 5, 54);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7030, 1, 56, 5, 53);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7031, 1, 63, 6, 104);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7032, 1, 62, 6, 103);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7033, 1, 61, 6, 102);
INSERT INTO ms079.keymap (id, characterid, `key`, type, action) VALUES (7034, 1, 60, 6, 101);