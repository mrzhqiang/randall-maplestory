create table mulungdojo
(
    id     int unsigned auto_increment
        primary key,
    charid int        default 0 not null,
    stage  tinyint(3) default 0 not null
)
    engine = MyISAM
    charset = utf8;

