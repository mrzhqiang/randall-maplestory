create table macfilters
(
    macfilterid int unsigned auto_increment
        primary key,
    filter      varchar(30) not null
)
    charset = utf8;

