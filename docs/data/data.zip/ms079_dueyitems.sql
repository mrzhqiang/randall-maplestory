create table dueyitems
(
    inventoryitemid int unsigned auto_increment
        primary key,
    characterid     int                    null,
    accountid       int(10)                null,
    packageid       int                    null,
    itemid          int         default 0  not null,
    inventorytype   int         default 0  not null,
    position        int         default 0  not null,
    quantity        int         default 0  not null,
    owner           tinytext               null,
    GM_Log          tinytext               null,
    uniqueid        int         default -1 not null,
    flag            int(2)      default 0  not null,
    expiredate      bigint      default -1 not null,
    type            tinyint(1)  default 0  not null,
    sender          varchar(15) default '' not null
)
    charset = utf8;

create index accountid
    on dueyitems (accountid);

create index characterid
    on dueyitems (characterid);

create index characterid_2
    on dueyitems (characterid, inventorytype);

create index inventoryitems_ibfk_1
    on dueyitems (characterid);

create index inventorytype
    on dueyitems (inventorytype);

create index packageid
    on dueyitems (packageid);

