create table aclog
(
    id          int unsigned auto_increment
        primary key,
    accid       int unsigned                        not null,
    bossid      varchar(20) charset utf8            not null,
    lastattempt timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP
)
    charset = latin1;

