create table playernpcs
(
    id       int auto_increment
        primary key,
    name     varchar(15)                 not null,
    hair     int                         not null,
    face     int                         not null,
    skin     int                         not null,
    x        int         default 0       not null,
    y        int         default 0       not null,
    map      int                         not null,
    charid   int                         not null,
    scriptid int                         not null,
    foothold int                         not null,
    dir      tinyint(1)  default 0       not null,
    gender   tinyint(1)  default 0       not null,
    pets     varchar(25) default '0,0,0' null,
    constraint playernpcs_ibfk_1
        foreign key (charid) references characters (id)
            on delete cascade
)
    charset = utf8;

create index scriptid
    on playernpcs (scriptid);

