create table playernpcs_equip
(
    id       int auto_increment
        primary key,
    npcid    int not null,
    equipid  int not null,
    equippos int not null,
    charid   int not null,
    constraint playernpcs_equip_ibfk_1
        foreign key (charid) references characters (id)
            on delete cascade,
    constraint playernpcs_equip_ibfk_2
        foreign key (npcid) references playernpcs (scriptid)
            on delete cascade
)
    charset = utf8;

