create table queststatusmobs
(
    queststatusmobid int unsigned auto_increment
        primary key,
    queststatusid    int unsigned default 0 not null,
    mob              int          default 0 not null,
    count            int          default 0 not null,
    constraint queststatusmobs_ibfk_1
        foreign key (queststatusid) references queststatus (queststatusid)
            on delete cascade
)
    charset = utf8;

create index queststatusid
    on queststatusmobs (queststatusid);

INSERT INTO ms079.queststatusmobs (queststatusmobid, queststatusid, mob, count) VALUES (102, 9140, 9400612, 0);