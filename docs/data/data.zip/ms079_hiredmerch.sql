create table hiredmerch
(
    PackageId   int unsigned auto_increment
        primary key,
    characterid int unsigned default 0 null,
    accountid   int unsigned           null,
    map         int(10)      default 0 not null,
    channel     int(2)       default 0 null,
    Mesos       int unsigned default 0 null,
    time        bigint unsigned        null
)
    charset = utf8;

INSERT INTO ms079.hiredmerch (PackageId, characterid, accountid, map, channel, Mesos, time) VALUES (2, 5, 5, 910000001, 1, 500, 1481427863183);