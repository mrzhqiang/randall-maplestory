create table csitems
(
    inventoryitemid int unsigned auto_increment
        primary key,
    characterid     int                    null,
    accountid       int(10)                null,
    packageid       int                    null,
    itemid          int         default 0  not null,
    inventorytype   int         default 0  not null,
    position        int         default 0  not null,
    quantity        int         default 0  not null,
    owner           tinytext               null,
    GM_Log          tinytext               null,
    uniqueid        int         default -1 not null,
    flag            int(2)      default 0  not null,
    expiredate      bigint      default -1 not null,
    type            tinyint(1)  default 0  not null,
    sender          varchar(13) default '' not null,
    itemlevel       int(3)      default 0  not null
)
    charset = utf8;

create index accountid
    on csitems (accountid);

create index characterid
    on csitems (characterid);

create index characterid_2
    on csitems (characterid, inventorytype);

create index inventoryitems_ibfk_1
    on csitems (characterid);

create index inventorytype
    on csitems (inventorytype);

create index packageid
    on csitems (packageid);

