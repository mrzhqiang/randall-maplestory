create table bbs_replies
(
    replyid   int unsigned auto_increment
        primary key,
    threadid  int unsigned           not null,
    postercid int unsigned           not null,
    timestamp bigint unsigned        not null,
    content   varchar(26) default '' not null,
    guildid   int         default 0  not null
)
    engine = MyISAM
    charset = utf8;

