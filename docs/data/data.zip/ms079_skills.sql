create table skills
(
    id          int auto_increment
        primary key,
    skillid     int     default 0  not null,
    characterid int     default 0  not null,
    skilllevel  tinyint default 0  not null,
    masterlevel tinyint default 0  not null,
    expiration  bigint  default -1 not null,
    constraint skills_ibfk_1
        foreign key (characterid) references characters (id)
            on delete cascade
)
    charset = utf8;

INSERT INTO ms079.skills (id, skillid, characterid, skilllevel, masterlevel, expiration) VALUES (1277, 12, 1, 0, 0, -1);
INSERT INTO ms079.skills (id, skillid, characterid, skilllevel, masterlevel, expiration) VALUES (1278, 1000, 1, 3, 0, -1);
INSERT INTO ms079.skills (id, skillid, characterid, skilllevel, masterlevel, expiration) VALUES (1279, 1002, 1, 3, 0, -1);
INSERT INTO ms079.skills (id, skillid, characterid, skilllevel, masterlevel, expiration) VALUES (1280, 2000000, 1, 16, 0, -1);
INSERT INTO ms079.skills (id, skillid, characterid, skilllevel, masterlevel, expiration) VALUES (1281, 2000001, 1, 10, 0, -1);
INSERT INTO ms079.skills (id, skillid, characterid, skilllevel, masterlevel, expiration) VALUES (1282, 9002, 1, 1, 1, -1);
INSERT INTO ms079.skills (id, skillid, characterid, skilllevel, masterlevel, expiration) VALUES (1283, 2001004, 1, 1, 0, -1);
INSERT INTO ms079.skills (id, skillid, characterid, skilllevel, masterlevel, expiration) VALUES (1284, 2001005, 1, 20, 0, -1);
INSERT INTO ms079.skills (id, skillid, characterid, skilllevel, masterlevel, expiration) VALUES (1285, 2001002, 1, 5, 0, -1);