create table savedlocations
(
    id           int auto_increment
        primary key,
    characterid  int           not null,
    locationtype int default 0 not null,
    map          int           not null,
    constraint savedlocations_ibfk_1
        foreign key (characterid) references characters (id)
            on delete cascade
)
    charset = utf8;

