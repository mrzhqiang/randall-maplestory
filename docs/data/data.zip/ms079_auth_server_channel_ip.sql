create table auth_server_channel_ip
(
    channelconfigid int unsigned auto_increment
        primary key,
    channelid       int unsigned default 0 not null,
    name            tinytext               not null,
    value           tinytext               not null
)
    engine = MyISAM
    charset = utf8;

create index channelid
    on auth_server_channel_ip (channelid);

INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (1, 2, 'net.sf.odinms.channel.net.port', '8587');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (2, 3, 'net.sf.odinms.channel.net.port', '8588');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (3, 4, 'net.sf.odinms.channel.net.port', '8589');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (4, 5, 'net.sf.odinms.channel.net.port', '8590');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (5, 6, 'net.sf.odinms.channel.net.port', '8591');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (6, 7, 'net.sf.odinms.channel.net.port', '8592');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (7, 8, 'net.sf.odinms.channel.net.port', '8593');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (8, 9, 'net.sf.odinms.channel.net.port', '8594');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (9, 10, 'net.sf.odinms.channel.net.port', '8595');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (10, 11, 'net.sf.odinms.channel.net.port', '7585');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (11, 12, 'net.sf.odinms.channel.net.port', '7586');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (12, 13, 'net.sf.odinms.channel.net.port', '7587');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (13, 14, 'net.sf.odinms.channel.net.port', '7588');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (14, 15, 'net.sf.odinms.channel.net.port', '7589');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (15, 16, 'net.sf.odinms.channel.net.port', '7590');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (16, 17, 'net.sf.odinms.channel.net.port', '7591');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (17, 18, 'net.sf.odinms.channel.net.port', '7592');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (18, 19, 'net.sf.odinms.channel.net.port', '7593');
INSERT INTO ms079.auth_server_channel_ip (channelconfigid, channelid, name, value) VALUES (19, 20, 'net.sf.odinms.channel.net.port', '7594');