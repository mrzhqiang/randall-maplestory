create table cashshop_limit_sell
(
    serial int           not null
        primary key,
    amount int default 0 not null
)
    engine = MyISAM
    charset = utf8;

