create table loginlog
(
    account   varchar(255) null,
    password  varchar(255) null,
    logintype varchar(255) null,
    ip        varchar(255) null,
    time      varchar(255) null,
    active    varchar(255) null
)
    charset = utf8;

