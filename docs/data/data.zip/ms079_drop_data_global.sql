create table drop_data_global
(
    id               bigint auto_increment
        primary key,
    continent        int                  not null,
    dropType         tinyint(1) default 0 not null,
    itemid           int        default 0 not null,
    minimum_quantity int        default 1 not null,
    maximum_quantity int        default 1 not null,
    questid          int        default 0 not null,
    chance           int        default 0 not null,
    comments         varchar(45)          null
)
    charset = gbk;

create index mobid
    on drop_data_global (continent);

INSERT INTO ms079.drop_data_global (id, continent, dropType, itemid, minimum_quantity, maximum_quantity, questid, chance, comments) VALUES (1, -1, 0, 2210040, 1, 1, 0, 10000, '萬聖節');
INSERT INTO ms079.drop_data_global (id, continent, dropType, itemid, minimum_quantity, maximum_quantity, questid, chance, comments) VALUES (2, -1, 0, 2210041, 1, 1, 0, 10000, '萬聖節');
INSERT INTO ms079.drop_data_global (id, continent, dropType, itemid, minimum_quantity, maximum_quantity, questid, chance, comments) VALUES (3, -1, 0, 2210042, 1, 1, 0, 10000, '萬聖節');
INSERT INTO ms079.drop_data_global (id, continent, dropType, itemid, minimum_quantity, maximum_quantity, questid, chance, comments) VALUES (4, -1, 0, 2210008, 1, 1, 0, 1000, '萬聖節');