create table speedruns
(
    id         int(11) unsigned auto_increment
        primary key,
    type       varchar(13)              not null,
    leader     varchar(13)              not null,
    timestring varchar(1024)            not null,
    time       bigint        default 0  not null,
    members    varchar(1024) default '' not null
)
    charset = utf8;

