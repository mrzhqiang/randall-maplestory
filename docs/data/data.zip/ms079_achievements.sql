create table achievements
(
    achievementid int(9) default 0 not null,
    charid        int(9) default 0 not null,
    accountid     int    default 0 not null,
    primary key (achievementid, charid)
)
    charset = utf8;

