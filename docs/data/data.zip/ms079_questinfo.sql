create table questinfo
(
    questinfoid int unsigned auto_increment
        primary key,
    characterid int    default 0 not null,
    quest       int(6) default 0 not null,
    customData  varchar(555)     null,
    constraint questsinfo_ibfk_1
        foreign key (characterid) references characters (id)
            on delete cascade
)
    charset = utf8;

create index characterid
    on questinfo (characterid);

INSERT INTO ms079.questinfo (questinfoid, characterid, quest, customData) VALUES (123, 1, 27000, 'enter=10001000000100010000');