create table accounts
(
    id            int auto_increment
        primary key,
    name          varchar(30)         default ''                    not null,
    password      varchar(128)        default ''                    not null,
    salt          varchar(32)                                       null,
    `2ndpassword` varchar(134)                                      null,
    salt2         varchar(32)                                       null,
    loggedin      tinyint(1) unsigned default 0                     not null,
    lastlogin     timestamp                                         null,
    createdat     timestamp           default CURRENT_TIMESTAMP     not null,
    birthday      date                default '2021-04-25'          not null,
    banned        tinyint(1)          default 0                     not null,
    banreason     text                                              null,
    gm            tinyint(1)          default 0                     not null,
    email         tinytext                                          null,
    macs          tinytext                                          null,
    tempban       timestamp           default '2021-04-25 00:00:00' not null,
    greason       tinyint(4) unsigned                               null,
    ACash         int                 default 0                     null,
    mPoints       int                                               null,
    gender        tinyint(2) unsigned default 10                    not null,
    SessionIP     varchar(64)                                       null,
    points        int                 default 0                     not null,
    vpoints       int                 default 0                     not null,
    lastlogon     timestamp                                         null,
    facebook_id   varchar(255)                                      null,
    access_token  varchar(255)        default ''                    null,
    password_otp  varchar(255)        default ''                    null,
    expiration    timestamp                                         null,
    VIP           int(3)                                            null,
    money         int(6)              default 0                     not null,
    moneyb        int(6)              default 0                     not null,
    lastGainHM    bigint              default 0                     not null,
    paypalNX      int                 default 0                     null,
    constraint name
        unique (name)
)
    charset = utf8;

create index ranking1
    on accounts (id, banned, gm);

INSERT INTO ms079.accounts (id, name, password, salt, `2ndpassword`, salt2, loggedin, lastlogin, createdat, birthday, banned, banreason, gm, email, macs, tempban, greason, ACash, mPoints, gender, SessionIP, points, vpoints, lastlogon, facebook_id, access_token, password_otp, expiration, VIP, money, moneyb, lastGainHM, paypalNX) VALUES (1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', null, '32E8175811197469fc3e95a6d92bccf746d9048f5368812e01fc3580d25ea24773a42f26768b62119c8142fd2fed3a7a260224a6a8bb333006c1e1cf55246783d5ff3c', 'fc0bab141f8895ec20990c200a95659a', 0, '2018-12-11 12:52:05', '2018-12-10 12:49:53', '2016-04-10', 0, null, 0, 'autoregister@mail.com', 'C4-34-6B-51-D9-96', '2021-04-25 00:00:00', null, 738860, 172500, 0, '/127.0.0.1', 0, 0, '2018-12-11 12:51:54', null, '', '', null, null, 0, 0, 0, 0);