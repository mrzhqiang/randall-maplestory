create table famelog
(
    famelogid      int auto_increment
        primary key,
    characterid    int       default 0                 not null,
    characterid_to int       default 0                 not null,
    `when`         timestamp default CURRENT_TIMESTAMP not null,
    constraint famelog_ibfk_1
        foreign key (characterid) references characters (id)
            on delete cascade
)
    charset = utf8;

create index characterid
    on famelog (characterid);

