create table ipbans
(
    ipbanid int unsigned auto_increment
        primary key,
    ip      varchar(40) default '' not null
)
    charset = utf8;

