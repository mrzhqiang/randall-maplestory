create table hiredmerchitems
(
    inventoryitemid int unsigned auto_increment
        primary key,
    characterid     int                    null,
    accountid       int(10)                null,
    packageid       int                    null,
    itemid          int         default 0  not null,
    inventorytype   int         default 0  not null,
    position        int         default 0  not null,
    quantity        int         default 0  not null,
    owner           tinytext               null,
    GM_Log          tinytext               null,
    uniqueid        int         default -1 not null,
    flag            int(2)      default 0  not null,
    expiredate      bigint      default -1 not null,
    type            tinyint(1)  default 0  not null,
    sender          varchar(15) default '' not null
)
    charset = utf8;

create index accountid
    on hiredmerchitems (accountid);

create index characterid
    on hiredmerchitems (characterid);

create index characterid_2
    on hiredmerchitems (characterid, inventorytype);

create index inventoryitems_ibfk_1
    on hiredmerchitems (characterid);

create index inventorytype
    on hiredmerchitems (inventorytype);

create index packageid
    on hiredmerchitems (packageid);

INSERT INTO ms079.hiredmerchitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (2, 5, 5, 2, 1342000, 1, 2, 1, '', null, -1, 0, -1, 5, '');