create table guilds
(
    guildid     int unsigned auto_increment
        primary key,
    leader      int unsigned      default 0       not null,
    GP          int               default 0       not null,
    logo        int unsigned                      null,
    logoColor   smallint unsigned default 0       not null,
    name        varchar(45)                       not null,
    rank1title  varchar(45)       default '公會長'   not null,
    rank2title  varchar(45)       default '公會副會長' not null,
    rank3title  varchar(45)       default '公會成員'  not null,
    rank4title  varchar(45)       default '公會成員'  not null,
    rank5title  varchar(45)       default '公會成員'  not null,
    capacity    int unsigned      default 10      not null,
    logoBG      int unsigned                      null,
    logoBGColor smallint unsigned default 0       not null,
    notice      varchar(101)                      null,
    signature   int               default 0       not null,
    alliance    int unsigned      default 0       not null
)
    charset = utf8;

