create table questmonster
(
    id        int auto_increment
        primary key,
    questid   int                                    null,
    monsterid int                                    null,
    zt        int                                    not null,
    charid    int                                    null,
    name      varchar(255) charset gb2312 default '' null
)
    engine = MyISAM
    charset = latin1;

