create table inventoryequipment
(
    inventoryequipmentid int unsigned auto_increment
        primary key,
    inventoryitemid      int unsigned     default 0  not null,
    upgradeslots         tinyint unsigned default 0  not null,
    level                tinyint unsigned default 0  not null,
    str                  smallint         default 0  not null,
    dex                  smallint         default 0  not null,
    `int`                smallint         default 0  not null,
    luk                  smallint         default 0  not null,
    hp                   smallint         default 0  not null,
    mp                   smallint         default 0  not null,
    watk                 smallint         default 0  not null,
    matk                 smallint         default 0  not null,
    wdef                 smallint         default 0  not null,
    mdef                 smallint         default 0  not null,
    acc                  smallint         default 0  not null,
    avoid                smallint         default 0  not null,
    hands                smallint         default 0  not null,
    speed                smallint         default 0  not null,
    jump                 smallint         default 0  not null,
    ViciousHammer        tinyint(2)       default 0  not null,
    itemEXP              int              default 0  not null,
    durability           mediumint        default -1 not null,
    enhance              tinyint(3)       default 0  not null,
    potential1           smallint(5)      default 0  not null,
    potential2           smallint(5)      default 0  not null,
    potential3           smallint(5)      default 0  not null,
    hpR                  smallint(5)      default 0  not null,
    mpR                  smallint(5)      default 0  not null,
    itemlevel            smallint(5)                 not null,
    constraint inventoryequipment_ibfk_1
        foreign key (inventoryitemid) references inventoryitems (inventoryitemid)
            on delete cascade
)
    charset = utf8;

create index inventoryitemid
    on inventoryequipment (inventoryitemid);

INSERT INTO ms079.inventoryequipment (inventoryequipmentid, inventoryitemid, upgradeslots, level, str, dex, `int`, luk, hp, mp, watk, matk, wdef, mdef, acc, avoid, hands, speed, jump, ViciousHammer, itemEXP, durability, enhance, potential1, potential2, potential3, hpR, mpR, itemlevel) VALUES (1116, 6690, 7, 0, 0, 0, 0, 0, 0, 0, 29, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO ms079.inventoryequipment (inventoryequipmentid, inventoryitemid, upgradeslots, level, str, dex, `int`, luk, hp, mp, watk, matk, wdef, mdef, acc, avoid, hands, speed, jump, ViciousHammer, itemEXP, durability, enhance, potential1, potential2, potential3, hpR, mpR, itemlevel) VALUES (1117, 6691, 0, 0, 999, 999, 999, 999, 0, 0, 999, 999, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO ms079.inventoryequipment (inventoryequipmentid, inventoryitemid, upgradeslots, level, str, dex, `int`, luk, hp, mp, watk, matk, wdef, mdef, acc, avoid, hands, speed, jump, ViciousHammer, itemEXP, durability, enhance, potential1, potential2, potential3, hpR, mpR, itemlevel) VALUES (1118, 6692, 0, 0, 999, 999, 999, 999, 0, 0, 999, 999, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO ms079.inventoryequipment (inventoryequipmentid, inventoryitemid, upgradeslots, level, str, dex, `int`, luk, hp, mp, watk, matk, wdef, mdef, acc, avoid, hands, speed, jump, ViciousHammer, itemEXP, durability, enhance, potential1, potential2, potential3, hpR, mpR, itemlevel) VALUES (1119, 6735, 7, 0, 0, 0, 0, 0, 0, 0, 23, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO ms079.inventoryequipment (inventoryequipmentid, inventoryitemid, upgradeslots, level, str, dex, `int`, luk, hp, mp, watk, matk, wdef, mdef, acc, avoid, hands, speed, jump, ViciousHammer, itemEXP, durability, enhance, potential1, potential2, potential3, hpR, mpR, itemlevel) VALUES (1120, 6736, 0, 0, 50, 50, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO ms079.inventoryequipment (inventoryequipmentid, inventoryitemid, upgradeslots, level, str, dex, `int`, luk, hp, mp, watk, matk, wdef, mdef, acc, avoid, hands, speed, jump, ViciousHammer, itemEXP, durability, enhance, potential1, potential2, potential3, hpR, mpR, itemlevel) VALUES (1121, 6737, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0);