create table skillmacros
(
    id          int auto_increment
        primary key,
    characterid int         default 0 not null,
    position    tinyint(11) default 0 not null,
    skill1      int         default 0 not null,
    skill2      int         default 0 not null,
    skill3      int         default 0 not null,
    name        varchar(60)           null,
    shout       tinyint(1)  default 0 not null
)
    engine = MyISAM
    charset = utf8;

