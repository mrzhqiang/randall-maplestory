create table buddies
(
    id          int auto_increment
        primary key,
    characterid int                      not null,
    buddyid     int                      not null,
    pending     tinyint     default 0    not null,
    groupname   varchar(16) default '其他' not null,
    constraint buddies_ibfk_1
        foreign key (characterid) references characters (id)
            on delete cascade
)
    charset = utf8;

