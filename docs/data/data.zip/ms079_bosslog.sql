create table bosslog
(
    bosslogid   int unsigned auto_increment
        primary key,
    characterid int unsigned                        not null,
    bossid      varchar(20)                         not null,
    lastattempt timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP
)
    charset = utf8;

