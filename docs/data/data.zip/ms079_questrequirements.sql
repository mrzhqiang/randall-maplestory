create table questrequirements
(
    questrequirementid int unsigned auto_increment
        primary key,
    questid            int default 0 not null,
    status             int default 0 not null,
    data               blob          not null
)
    engine = MyISAM
    charset = utf8;

