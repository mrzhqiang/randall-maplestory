create table wz_questactskilldata
(
    id          int auto_increment
        primary key,
    skillid     int default 0  not null,
    skillLevel  int default -1 not null,
    masterLevel int default -1 not null,
    uniqueid    int default 0  not null
)
    engine = MyISAM
    charset = gbk;

INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (79, 10001004, 1, 1, 136);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (80, 11111004, 0, 20, 149);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (81, 12111004, 0, 20, 151);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (82, 13111002, 0, 20, 153);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (83, 14111005, 0, 20, 155);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (84, 15111004, 0, 20, 157);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (85, 11110005, 0, 10, 160);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (86, 12111003, 0, 20, 162);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (87, 13110003, 0, 20, 164);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (88, 14110004, 0, 20, 166);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (89, 15111005, 0, 20, 168);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (90, 20001005, 1, 1, 278);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (91, 20001004, 1, 1, 287);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (92, 21110002, 0, 20, 350);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (93, 9001, 1, 1, 429);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (94, 9002, 1, 1, 431);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (95, 9002, 1, 1, 433);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (96, 9001, 1, 1, 435);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (97, 9000, 1, 1, 437);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (98, 1016, 1, 1, 1129);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (99, 10001017, 1, 1, 1133);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (100, 10001003, 1, 1, 1135);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (101, 1003, 1, 1, 1135);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (102, 20001003, 1, 1, 1135);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (103, 1004, 1, 1, 1136);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (104, 1003, 1, 1, 1147);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (105, 1004, 1, 1, 1147);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (106, 1007, 1, 3, 1178);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (107, 10001007, 1, 3, 1178);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (108, 20001007, 1, 3, 1178);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (109, 1007, 0, 0, 1180);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (110, 3121008, 0, 10, 1198);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (111, 3221007, 0, 10, 1198);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (112, 2321003, 0, 10, 1202);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (113, 2321003, 0, 15, 1204);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (114, 2321003, 0, 20, 1206);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (115, 2321003, 0, 25, 1208);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (116, 2321003, 0, 30, 1210);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (117, 2321006, 0, 10, 1217);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (118, 4221004, 0, 10, 1218);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (119, 4121004, 0, 10, 1218);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (120, 1121010, 0, 10, 1225);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (121, 1320006, 0, 10, 1225);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (122, 1221011, 0, 10, 1225);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (123, 2121007, 0, 10, 1229);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (124, 2221007, 0, 10, 1231);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (125, 2321008, 0, 10, 1233);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (126, 1120005, 0, 10, 1235);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (127, 1220006, 0, 10, 1235);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (128, 1121002, 0, 10, 1239);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (129, 1221002, 0, 10, 1239);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (130, 1321002, 0, 10, 1239);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (131, 4221001, 0, 10, 1241);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (132, 2121005, 0, 10, 1252);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (133, 4121008, 0, 10, 1257);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (134, 3121006, 0, 10, 1258);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (135, 3221005, 0, 10, 1259);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (136, 3121004, 0, 10, 1261);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (137, 3221001, 0, 10, 1263);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (138, 1221003, 0, 10, 1273);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (139, 1221004, 0, 10, 1273);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (140, 1320008, 0, 5, 1276);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (141, 1320008, 0, 15, 1278);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (142, 1320008, 0, 25, 1280);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (143, 1320009, 0, 5, 1282);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (144, 1320009, 0, 15, 1284);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (145, 1320009, 0, 25, 1286);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (146, 2221005, 0, 10, 1297);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (147, 5121003, 0, 10, 1305);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (148, 5121005, 0, 10, 1307);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (149, 5121004, 0, 10, 1309);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (150, 5121010, 0, 10, 1313);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (151, 5221006, 0, 10, 1314);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (152, 5221007, 0, 10, 1316);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (153, 5221008, 0, 10, 1318);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (154, 5221003, 0, 10, 1319);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (155, 5221009, 0, 10, 1320);
INSERT INTO ms079.wz_questactskilldata (id, skillid, skillLevel, masterLevel, uniqueid) VALUES (156, 1005, 1, 1, 1321);