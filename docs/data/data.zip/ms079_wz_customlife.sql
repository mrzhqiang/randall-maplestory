create table wz_customlife
(
    id      int auto_increment
        primary key,
    dataid  int                     not null,
    f       int                     not null,
    hide    tinyint(1) default 0    not null,
    fh      int                     not null,
    type    varchar(1)              not null,
    cy      int                     not null,
    rx0     int                     not null,
    rx1     int                     not null,
    x       int                     not null,
    y       int                     not null,
    mobtime int        default 1000 null,
    mid     int                     not null
)
    charset = latin1;

