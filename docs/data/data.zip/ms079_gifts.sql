create table gifts
(
    giftid    int unsigned auto_increment
        primary key,
    recipient int          default 0  not null,
    `from`    varchar(13)  default '' not null,
    message   varchar(255) default '' not null,
    sn        int          default 0  not null,
    uniqueid  int          default 0  not null
)
    charset = utf8;

