create table prizelog
(
    id     int unsigned auto_increment
        primary key,
    accid  int unsigned             not null,
    bossid varchar(20) charset utf8 not null
)
    charset = latin1;

