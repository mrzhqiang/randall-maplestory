create table uselog
(
    account     varchar(255) null,
    ip          varchar(255) null,
    time        varchar(255) null,
    usetype     varchar(255) null,
    active      varchar(255) null,
    newpassword varchar(255) null,
    oldpassword varchar(255) null
)
    charset = utf8;

