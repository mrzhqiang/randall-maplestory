create table nxcode
(
    code  varchar(30)               not null
        primary key,
    valid int default 1             not null,
    user  varchar(15)               null,
    type  int default 0             not null,
    item  int default 10000         not null,
    size  int(11) unsigned zerofill null
)
    engine = MyISAM
    charset = utf8;

