create table accounts_info
(
    id           int auto_increment
        primary key,
    accId        int default 0 not null,
    worldId      int default 0 not null,
    cardSlots    int default 3 not null,
    gamePoints   int default 0 not null comment '在线时间点',
    updateTime   timestamp     null comment '时间戳',
    gamePointspd int default 0 not null,
    gamePointsps int default 0 not null,
    sjrw         int default 0 not null,
    sgrw         int default 0 not null,
    fbrw         int default 0 null,
    sbossrw      int default 0 null,
    sgrwa        int default 0 null,
    fbrwa        int default 0 null,
    sbossrwa     int default 0 null,
    lb           int default 0 null
)
    charset = gbk;

create index accid
    on accounts_info (accId);

create index worldid
    on accounts_info (worldId);

INSERT INTO ms079.accounts_info (id, accId, worldId, cardSlots, gamePoints, updateTime, gamePointspd, gamePointsps, sjrw, sgrw, fbrw, sbossrw, sgrwa, fbrwa, sbossrwa, lb) VALUES (1, 1, 0, 3, 47, '2018-12-11 13:48:13', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);