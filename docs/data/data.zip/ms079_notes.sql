create table notes
(
    id        int auto_increment
        primary key,
    `to`      varchar(15) default '' not null,
    `from`    varchar(15) default '' not null,
    message   text                   not null,
    timestamp bigint unsigned        not null,
    gift      tinyint(1)  default 0  not null
)
    charset = utf8;

