create table mts_items
(
    id          int                    not null
        primary key,
    tab         tinyint(1)  default 1  not null,
    price       int         default 0  not null,
    characterid int         default 0  not null,
    seller      varchar(15) default '' not null,
    expiration  bigint      default 0  not null
)
    charset = utf8;

