create table game_poll_reply
(
    id        int unsigned auto_increment
        primary key,
    AccountId int unsigned                  not null,
    SelectAns tinyint(5) unsigned default 0 not null
)
    charset = utf8;

