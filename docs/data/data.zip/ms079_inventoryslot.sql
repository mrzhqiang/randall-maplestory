create table inventoryslot
(
    id          int unsigned auto_increment
        primary key,
    characterid int unsigned     null,
    equip       tinyint unsigned null,
    `use`       tinyint unsigned null,
    setup       tinyint unsigned null,
    etc         tinyint unsigned null,
    cash        tinyint unsigned null
)
    charset = utf8;

INSERT INTO ms079.inventoryslot (id, characterid, equip, `use`, setup, etc, cash) VALUES (198, 1, 96, 96, 96, 96, 96);