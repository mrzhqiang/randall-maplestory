create table hiredmerchequipment
(
    inventoryequipmentid int unsigned auto_increment
        primary key,
    inventoryitemid      int unsigned default 0  not null,
    upgradeslots         int          default 0  not null,
    level                int          default 0  not null,
    str                  int          default 0  not null,
    dex                  int          default 0  null,
    `int`                int          default 0  not null,
    luk                  int          default 0  not null,
    hp                   int          default 0  not null,
    mp                   int          default 0  not null,
    watk                 int          default 0  not null,
    matk                 int          default 0  not null,
    wdef                 int          default 0  not null,
    mdef                 int          default 0  not null,
    acc                  int          default 0  not null,
    avoid                int          default 0  not null,
    hands                int          default 0  not null,
    speed                int          default 0  not null,
    jump                 int          default 0  not null,
    ViciousHammer        tinyint(2)   default 0  not null,
    itemEXP              int          default 0  not null,
    durability           int          default -1 not null,
    enhance              tinyint(3)   default 0  not null,
    potential1           smallint(5)  default 0  not null,
    potential2           smallint(5)  default 0  not null,
    potential3           smallint(5)  default 0  not null,
    hpR                  smallint(5)  default 0  not null,
    mpR                  smallint(5)  default 0  not null,
    itemlevel            smallint(5)  default 0  not null,
    constraint hiredmerchantequipment_ibfk_1
        foreign key (inventoryitemid) references hiredmerchitems (inventoryitemid)
            on delete cascade
)
    charset = utf8;

create index inventoryitemid
    on hiredmerchequipment (inventoryitemid);

INSERT INTO ms079.hiredmerchequipment (inventoryequipmentid, inventoryitemid, upgradeslots, level, str, dex, `int`, luk, hp, mp, watk, matk, wdef, mdef, acc, avoid, hands, speed, jump, ViciousHammer, itemEXP, durability, enhance, potential1, potential2, potential3, hpR, mpR, itemlevel) VALUES (2, 2, 7, 0, 0, 0, 0, 0, 147, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0);