create table ipvotelog
(
    vid       int unsigned auto_increment
        primary key,
    accid     varchar(45)         default '0'         not null,
    ipaddress varchar(30)         default '127.0.0.1' not null,
    votetime  varchar(100)        default '0'         not null,
    votetype  tinyint(1) unsigned default 0           not null
)
    charset = utf8;

