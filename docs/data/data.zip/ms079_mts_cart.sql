create table mts_cart
(
    id          int unsigned auto_increment
        primary key,
    characterid int default 0 not null,
    itemid      int default 0 not null
)
    charset = utf8;

