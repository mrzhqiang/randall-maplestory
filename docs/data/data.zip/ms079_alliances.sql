create table alliances
(
    id       int auto_increment
        primary key,
    name     varchar(13)                  not null,
    leaderid int                          not null,
    guild1   int                          not null,
    guild2   int                          not null,
    guild3   int          default 0       not null,
    guild4   int          default 0       not null,
    guild5   int          default 0       not null,
    rank1    varchar(13)  default '公會長'   not null,
    rank2    varchar(13)  default '公會副會長' not null,
    rank3    varchar(13)  default '公會成員'  not null,
    rank4    varchar(13)  default '公會成員'  not null,
    rank5    varchar(13)  default '公會成員'  not null,
    capacity int          default 2       not null,
    notice   varchar(100) default ''      not null
)
    charset = utf8;

