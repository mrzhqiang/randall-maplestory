create table trocklocations
(
    trockid     int auto_increment
        primary key,
    characterid int null,
    mapid       int null
)
    engine = MyISAM
    charset = utf8;

INSERT INTO ms079.trocklocations (trockid, characterid, mapid) VALUES (3589, 12, 200000100);
INSERT INTO ms079.trocklocations (trockid, characterid, mapid) VALUES (3418, 4, 100000200);
INSERT INTO ms079.trocklocations (trockid, characterid, mapid) VALUES (3588, 12, 220000000);
INSERT INTO ms079.trocklocations (trockid, characterid, mapid) VALUES (3417, 4, 105070001);
INSERT INTO ms079.trocklocations (trockid, characterid, mapid) VALUES (3416, 4, 200000100);
INSERT INTO ms079.trocklocations (trockid, characterid, mapid) VALUES (3415, 4, 211000001);
INSERT INTO ms079.trocklocations (trockid, characterid, mapid) VALUES (3695, 19, 103030200);