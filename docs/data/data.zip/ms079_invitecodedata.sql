create table invitecodedata
(
    id     int auto_increment
        primary key,
    code   varchar(255)       not null,
    user   varchar(255)       null,
    time   varchar(255)       null,
    ip     varchar(255)       null,
    active int(255) default 0 not null
)
    charset = utf8;

