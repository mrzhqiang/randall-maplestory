create table families
(
    familyid int auto_increment
        primary key,
    leaderid int          default 0  not null,
    notice   varchar(255) default '' not null
)
    charset = utf8;

