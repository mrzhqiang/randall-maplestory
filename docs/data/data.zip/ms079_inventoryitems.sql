create table inventoryitems
(
    inventoryitemid int unsigned auto_increment
        primary key,
    characterid     int                    null,
    accountid       int(10)                null,
    packageid       int                    null,
    itemid          int         default 0  not null,
    inventorytype   int         default 0  not null,
    position        int         default 0  not null,
    quantity        int         default 0  not null,
    owner           tinytext               null,
    GM_Log          tinytext               null,
    uniqueid        int         default -1 not null,
    flag            int(2)      default 0  not null,
    expiredate      bigint      default -1 not null,
    type            tinyint(1)  default 0  not null,
    sender          varchar(15) default '' not null
)
    charset = utf8;

create index accountid
    on inventoryitems (accountid);

create index characterid_2
    on inventoryitems (characterid, inventorytype);

create index inventorytype
    on inventoryitems (inventorytype);

create index packageid
    on inventoryitems (packageid);

INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6690, 1, null, null, 1382002, 1, 1, 1, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6691, 1, null, null, 1072153, 1, 2, 1, '', null, 17, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6692, 1, null, null, 1082102, 1, 3, 1, '', null, 18, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6693, 1, null, null, 2000002, 2, 1, 92, '0 时间 2018-12-10', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6694, 1, null, null, 2000002, 2, 2, 100, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6695, 1, null, null, 2000002, 2, 3, 100, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6696, 1, null, null, 2000006, 2, 4, 96, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6697, 1, null, null, 2000006, 2, 5, 100, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6698, 1, null, null, 2000006, 2, 6, 100, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6699, 1, null, null, 2010000, 2, 7, 100, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6700, 1, null, null, 2010001, 2, 8, 100, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6701, 1, null, null, 2010002, 2, 9, 100, '0 时间 2018-12-10', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6702, 1, null, null, 2010003, 2, 10, 100, '0 时间 2018-12-10', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6703, 1, null, null, 2010004, 2, 11, 100, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6704, 1, null, null, 2030000, 2, 13, 100, '0 时间 2018-12-10', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6705, 1, null, null, 2030002, 2, 14, 100, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6706, 1, null, null, 2120000, 2, 15, 200, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6707, 1, null, null, 2120000, 2, 16, 200, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6708, 1, null, null, 2120000, 2, 12, 200, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6709, 1, null, null, 3010000, 3, 1, 1, '0 时间 2018-12-10', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6710, 1, null, null, 4000000, 4, 1, 9, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6711, 1, null, null, 4000004, 4, 2, 66, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6712, 1, null, null, 4000005, 4, 3, 31, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6713, 1, null, null, 4000010, 4, 4, 85, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6714, 1, null, null, 4000011, 4, 5, 10, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6715, 1, null, null, 4000016, 4, 6, 4, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6716, 1, null, null, 4000019, 4, 7, 8, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6717, 1, null, null, 4001126, 4, 8, 51, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6718, 1, null, null, 4001356, 4, 9, 12, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6719, 1, null, null, 4010005, 4, 10, 2, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6720, 1, null, null, 4020004, 4, 11, 2, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6721, 1, null, null, 4000003, 4, 12, 20, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6722, 1, null, null, 4000017, 4, 13, 6, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6723, 1, null, null, 4010006, 4, 14, 1, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6724, 1, null, null, 4000002, 4, 15, 9, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6725, 1, null, null, 4003004, 4, 16, 9, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6726, 1, null, null, 4000021, 4, 17, 2, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6727, 1, null, null, 4000001, 4, 18, 80, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6728, 1, null, null, 4020000, 4, 19, 2, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6729, 1, null, null, 4000006, 4, 20, 25, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6730, 1, null, null, 4020002, 4, 21, 1, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6731, 1, null, null, 4000018, 4, 22, 29, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6732, 1, null, null, 4032495, 4, 23, 1, '任务获得 28198 时间: 2018-12-11', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6733, 1, null, null, 5000026, 5, 2, 1, '', null, 16, 0, 1552282730066, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6734, 1, null, null, 5041000, 5, 1, 30, '', null, 13, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6735, 1, null, null, 1382003, -1, -11, 1, '', null, -1, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6736, 1, null, null, 1002186, -1, -101, 1, '', null, 9, 0, -1, 0, '');
INSERT INTO ms079.inventoryitems (inventoryitemid, characterid, accountid, packageid, itemid, inventorytype, position, quantity, owner, GM_Log, uniqueid, flag, expiredate, type, sender) VALUES (6737, 1, null, null, 1050146, -1, -105, 1, '', null, 12, 0, -1, 0, '');