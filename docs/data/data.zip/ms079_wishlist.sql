create table wishlist
(
    characterid int not null,
    sn          int not null
)
    engine = MyISAM
    charset = utf8;

INSERT INTO ms079.wishlist (characterid, sn) VALUES (9, 70000044);
INSERT INTO ms079.wishlist (characterid, sn) VALUES (4, 30200016);