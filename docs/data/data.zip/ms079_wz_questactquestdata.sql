create table wz_questactquestdata
(
    id       int auto_increment
        primary key,
    quest    int        default 0 not null,
    state    tinyint(1) default 2 not null,
    uniqueid int        default 0 not null
)
    engine = MyISAM
    charset = gbk;

INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (20, 20300, 2, 99);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (21, 2100, 2, 232);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (22, 2144, 2, 275);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (23, 2198, 2, 371);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (24, 2198, 2, 372);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (25, 2199, 2, 373);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (26, 2200, 2, 373);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (27, 2201, 2, 374);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (28, 2202, 2, 375);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (29, 2205, 2, 379);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (30, 3080, 2, 580);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (31, 3081, 2, 582);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (32, 3334, 2, 692);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (33, 3521, 2, 816);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (34, 3521, 2, 824);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (35, 3641, 2, 872);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (36, 3926, 2, 971);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (37, 4307, 2, 1015);
INSERT INTO ms079.wz_questactquestdata (id, quest, state, uniqueid) VALUES (38, 6033, 2, 1179);