create table auth_server_login
(
    loginserverid int unsigned auto_increment
        primary key,
    `key`         varchar(40) default '' not null,
    world         int         default 0  not null
)
    engine = MyISAM
    charset = utf8;

INSERT INTO ms079.auth_server_login (loginserverid, `key`, world) VALUES (1, 'e709b6bfc9eda84c166514ec9784739c6cc201bd', 0);