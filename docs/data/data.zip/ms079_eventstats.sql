create table eventstats
(
    eventstatid int unsigned auto_increment
        primary key,
    event       varchar(30)                         not null,
    instance    varchar(30)                         not null,
    characterid int                                 not null,
    channel     int                                 not null,
    time        timestamp default CURRENT_TIMESTAMP not null
)
    charset = utf8;

