create table pets
(
    petid     int unsigned auto_increment
        primary key,
    name      varchar(13)           null,
    level     int(3) unsigned       not null,
    closeness int(6) unsigned       not null,
    fullness  int(3) unsigned       not null,
    seconds   int         default 0 not null,
    flags     smallint(5) default 0 not null
)
    charset = utf8;

INSERT INTO ms079.pets (petid, name, level, closeness, fullness, seconds, flags) VALUES (16, '齐天大圣', 1, 1, 100, 0, 55);