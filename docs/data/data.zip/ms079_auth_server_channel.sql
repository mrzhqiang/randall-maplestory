create table auth_server_channel
(
    channelid int unsigned auto_increment
        primary key,
    world     int         default 0  not null,
    number    int                    null,
    `key`     varchar(40) default '' not null
)
    engine = MyISAM
    charset = utf8;

INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (1, 0, 1, '64cc5ec141f3d07fb076ba87c5c46825c44a997c');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (2, 0, 2, '71278272bd03d969454d32211592f6660a11b8ee');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (3, 0, 3, 'ce1a2a86d8f4f5bab9e600dcac20388d54403915');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (4, 0, 4, '0c508d5b595790b9af143d5ea98973c58d34a0b8');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (5, 0, 5, 'afe0f764a60b96c0265966b45091680c520b791b');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (6, 0, 6, 'a63c74dfb6dd62c2caef06184c1f41fa75eed514');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (7, 0, 7, 'e05a1b16f8b24d43cdf50a242b5641e33f275a21');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (8, 0, 8, '4183d0b0ef17d9130433523b6d7c845755782e87');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (9, 0, 9, '05a7864614180db4d3374e680039d55279ebdb8c');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (10, 0, 10, '7ce024fdb03cf3ef03171828bff527269d01f08f');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (11, 0, 11, '7e1994fe975472f827ecc71188cb5d64bdc24c1d');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (12, 0, 12, '462538d6ee0a15c0ff52f4bf09da6d60bc3a657d');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (13, 0, 13, 'd82cfcb1edcb2e31b751b3ccfeb7464500bb30dc');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (14, 0, 14, '2f32eeea3628e70980dab4e6ec2f9d27a3313b96');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (15, 0, 15, 'f5bf68e8d67b5e5f3f2ebe684a85fe72166db8f2');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (16, 0, 16, 'cf97404e96937aa89557a3af5c0d252b654e1b3a');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (17, 0, 17, '00edfe19b7f9c1b5303ce7a679452b3b6d3fe381');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (18, 0, 18, 'a9e267e5bdad70925db1729acd38f93b6edff9d4');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (19, 0, 19, '518fa6b3a88ce3ab6d688d2ac1e42a0754720664');
INSERT INTO ms079.auth_server_channel (channelid, world, number, `key`) VALUES (20, 0, 20, '923dcc504ed557f563fe52c82517a2b1feceeba1');