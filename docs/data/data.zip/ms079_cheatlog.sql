create table cheatlog
(
    id              int auto_increment
        primary key,
    characterid     int       default 0                 not null,
    offense         tinytext                            not null,
    count           int       default 0                 not null,
    lastoffensetime timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP,
    param           tinytext                            not null
)
    engine = MyISAM
    charset = utf8;

create index cid
    on cheatlog (characterid);

