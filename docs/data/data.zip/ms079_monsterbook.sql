create table monsterbook
(
    id     int(10) auto_increment
        primary key,
    charid int unsigned        default 0 not null,
    cardid int unsigned        default 0 not null,
    level  tinyint(2) unsigned default 1 null
)
    charset = utf8;

INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (102, 9, 2380001, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (155, 3, 2380011, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (156, 3, 2380012, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (284, 10, 2380005, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2460, 12, 2380004, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2461, 12, 2380005, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2462, 12, 2381007, 3);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2463, 12, 2381016, 3);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2464, 12, 2381034, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2465, 12, 2382092, 4);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2466, 12, 2382093, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2467, 12, 2382094, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2468, 12, 2382095, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2469, 12, 2382096, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (2470, 12, 2380009, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3259, 4, 2380001, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3260, 4, 2380005, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3261, 4, 2380008, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3262, 4, 2381007, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3263, 4, 2381016, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3264, 4, 2381083, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3265, 4, 2382092, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3266, 4, 2382093, 4);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3267, 4, 2382094, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3268, 4, 2382095, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3269, 4, 2382096, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3270, 4, 2383029, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3271, 4, 2381003, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (3272, 4, 2382047, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5451, 19, 2380003, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5452, 19, 2380007, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5453, 19, 2380010, 2);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5454, 19, 2380011, 3);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5455, 19, 2381034, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5456, 19, 2382004, 2);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5457, 19, 2382049, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5458, 19, 2382092, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5459, 19, 2382093, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5460, 19, 2382094, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5461, 19, 2382095, 5);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5462, 19, 2382096, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5463, 19, 2383043, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5464, 1, 2380005, 2);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5465, 1, 2381008, 1);
INSERT INTO ms079.monsterbook (id, charid, cardid, level) VALUES (5466, 1, 2382093, 1);