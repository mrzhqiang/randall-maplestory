create table onetimelog
(
    id          int unsigned auto_increment
        primary key,
    characterid int unsigned             not null,
    log         varchar(20) charset utf8 not null
)
    charset = latin1;

