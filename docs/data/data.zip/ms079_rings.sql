create table rings
(
    ringid        int auto_increment
        primary key,
    partnerRingId int default 0 not null,
    partnerChrId  int default 0 not null,
    itemid        int default 0 not null,
    partnername   varchar(255)  not null
)
    charset = utf8;

