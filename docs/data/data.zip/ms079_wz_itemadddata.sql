create table wz_itemadddata
(
    id     int auto_increment
        primary key,
    itemid int          not null,
    `key`  varchar(30)  not null,
    subKey varchar(30)  not null,
    value  varchar(255) not null
)
    engine = MyISAM
    charset = utf8;

INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (1, 1112736, 'statinc', 'incSTR', '2');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (2, 1112736, 'statinc', 'incINT', '2');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (3, 1112736, 'statinc', 'incDEX', '2');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (4, 1112736, 'statinc', 'incLUK', '2');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (5, 1112736, 'statinc', 'incPAD', '1');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (6, 1112736, 'statinc', 'incMAD', '1');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (7, 1112736, 'statinc', 'con:job', '2111,2112,2215,2216,2217,2218');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (8, 1112740, 'statinc', 'incDEX', '2');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (9, 1112740, 'statinc', 'incPAD', '1');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (10, 1112740, 'statinc', 'con:job', '311,312,321,322,1311,1312');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (11, 1112740, 'critical', 'con:job', '312,322,1312');
INSERT INTO ms079.wz_itemadddata (id, itemid, `key`, subKey, value) VALUES (12, 1112740, 'critical', 'prob', '5');