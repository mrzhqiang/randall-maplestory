create table auth_server_cs
(
    CashShopServerId int unsigned auto_increment
        primary key,
    `key`            varchar(40)                not null,
    world            int(11) unsigned default 0 not null
)
    engine = MyISAM
    charset = utf8;

INSERT INTO ms079.auth_server_cs (CashShopServerId, `key`, world) VALUES (1, '9eafbf39c3d7a53f7dab1f1dc4d380ce9314f7a4', 0);