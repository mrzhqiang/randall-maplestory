create table mountdata
(
    id          int unsigned auto_increment
        primary key,
    characterid int unsigned              null,
    Level       int(3) unsigned default 0 not null,
    Exp         int unsigned    default 0 not null,
    Fatigue     int(3) unsigned default 0 not null
)
    engine = MyISAM
    charset = utf8;

INSERT INTO ms079.mountdata (id, characterid, Level, Exp, Fatigue) VALUES (29, 1, 1, 0, 0);