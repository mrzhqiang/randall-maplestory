create table hypay
(
    id        int auto_increment
        primary key,
    accname   text charset utf8 null,
    payUsed   int(3)            not null,
    pay       int(3)            not null,
    payReward int(3)            not null
)
    charset = latin1;

INSERT INTO ms079.hypay (id, accname, payUsed, pay, payReward) VALUES (1, 'admin', 0, 0, 0);