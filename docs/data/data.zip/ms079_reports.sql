create table reports
(
    id         int unsigned auto_increment
        primary key,
    reporttime timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP,
    reporterid int                                 not null,
    victimid   int                                 not null,
    reason     tinyint                             not null,
    chatlog    text                                not null,
    status     text                                not null
)
    charset = utf8;

