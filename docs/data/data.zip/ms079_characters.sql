create table characters
(
    id               int auto_increment
        primary key,
    accountid        int                 default 0                     not null,
    world            tinyint(1)          default 0                     not null,
    name             varchar(20)         default ''                    not null,
    level            int(3) unsigned     default 0                     not null,
    exp              int                 default 0                     not null,
    str              int(5)              default 0                     not null,
    dex              int(5)              default 0                     not null,
    luk              int(5)              default 0                     not null,
    `int`            int(5)              default 0                     not null,
    hp               int(5)              default 0                     not null,
    mp               int(5)              default 0                     not null,
    maxhp            int(5)              default 0                     not null,
    maxmp            int(5)              default 0                     not null,
    meso             int                 default 0                     not null,
    hpApUsed         int(5)              default 0                     not null,
    job              int(5)              default 0                     not null,
    skincolor        tinyint(1)          default 0                     not null,
    gender           tinyint(1)          default 0                     not null,
    fame             int(5)              default 0                     not null,
    hair             int                 default 0                     not null,
    face             int                 default 0                     not null,
    ap               int(5)              default 0                     not null,
    map              int                 default 0                     not null,
    spawnpoint       int(3)              default 0                     not null,
    gm               int(3)              default 0                     not null,
    party            int                 default 0                     not null,
    buddyCapacity    int(3)              default 25                    not null,
    createdate       timestamp           default CURRENT_TIMESTAMP     not null,
    guildid          int unsigned        default 0                     not null,
    guildrank        tinyint(1) unsigned default 5                     not null,
    allianceRank     tinyint(1) unsigned default 5                     not null,
    monsterbookcover int(11) unsigned    default 0                     not null,
    dojo_pts         int(11) unsigned    default 0                     not null,
    dojoRecord       tinyint(2) unsigned default 0                     not null,
    pets             varchar(13)         default '-1,-1,-1'            not null,
    sp               varchar(255)        default '0,0,0,0,0,0,0,0,0,0' not null,
    subcategory      int                 default 0                     not null,
    Jaguar           int(3)              default 0                     not null,
    `rank`           int                 default 1                     not null,
    rankMove         int                 default 0                     not null,
    jobRank          int                 default 1                     not null,
    jobRankMove      int                 default 0                     not null,
    marriageId       int                 default 0                     not null,
    familyid         int                 default 0                     not null,
    seniorid         int                 default 0                     not null,
    junior1          int                 default 0                     not null,
    junior2          int                 default 0                     not null,
    currentrep       int                 default 0                     not null,
    totalrep         int                 default 0                     not null,
    charmessage      varchar(128)        default '安安'                  not null,
    expression       int                 default 0                     not null,
    constellation    int                 default 0                     not null,
    blood            int                 default 0                     not null,
    month            int                 default 0                     not null,
    day              int                 default 0                     not null,
    beans            int                 default 0                     not null,
    prefix           int(255)            default 0                     null,
    skillzq          int                 default 0                     not null,
    grname           int                 default 0                     not null,
    jzname           int                 default 0                     not null,
    mrfbrw           int                 default 0                     not null,
    mrsjrw           int                 default 0                     not null,
    mrsgrw           int                 default 0                     not null,
    mrsbossrw        int                 default 0                     not null,
    hythd            int                 default 0                     not null,
    mrsgrwa          int                 default 0                     not null,
    mrfbrwa          int                 default 0                     not null,
    mrsbossrwa       int                 default 0                     not null,
    mrsgrws          int                 default 0                     not null,
    mrsbossrws       int                 default 0                     not null,
    mrfbrws          int                 default 0                     not null,
    mrsgrwas         int                 default 0                     not null,
    mrsbossrwas      int                 default 0                     not null,
    mrfbrwas         int                 default 0                     not null,
    ddj              int                 default 0                     null,
    vip              int                 default 0                     null,
    bosslog          int                 default 0                     null,
    djjl             int                 default 0                     not null,
    qiandao          int                 default 0                     not null,
    mountid          int                 default 0                     not null,
    sg               int                 default 0                     not null
)
    charset = gbk;

create index accountid
    on characters (accountid);

create index party
    on characters (party);

create index ranking1
    on characters (level, exp);

create index ranking2
    on characters (gm, job);

INSERT INTO ms079.characters (id, accountid, world, name, level, exp, str, dex, luk, `int`, hp, mp, maxhp, maxmp, meso, hpApUsed, job, skincolor, gender, fame, hair, face, ap, map, spawnpoint, gm, party, buddyCapacity, createdate, guildid, guildrank, allianceRank, monsterbookcover, dojo_pts, dojoRecord, pets, sp, subcategory, Jaguar, `rank`, rankMove, jobRank, jobRankMove, marriageId, familyid, seniorid, junior1, junior2, currentrep, totalrep, charmessage, expression, constellation, blood, month, day, beans, prefix, skillzq, grname, jzname, mrfbrw, mrsjrw, mrsgrw, mrsbossrw, hythd, mrsgrwa, mrfbrwa, mrsbossrwa, mrsgrws, mrsbossrws, mrfbrws, mrsgrwas, mrsbossrwas, mrfbrwas, ddj, vip, bosslog, djjl, qiandao, mountid, sg) VALUES (1, 1, 0, '犀利哥', 25, 1000, 4, 4, 4, 133, 356, 1381, 356, 1381, 90306143, 0, 200, 2, 0, 100, 30730, 20100, 0, 101000000, 35, 6, -1, 20, '2018-12-10 12:50:15', 0, 5, 5, 0, 0, 0, '-1,-1,-1', '0,0,0,0,0,0,0,0,0,0', 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '安安', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 210100, 3220000, 0, 7130601, 1, 8180000, 117, 1, 6, 186, 2, 3, 0, 0, 0, 0, 0, 0, 0);