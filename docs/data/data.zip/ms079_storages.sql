create table storages
(
    storageid int unsigned auto_increment
        primary key,
    accountid int default 0 not null,
    slots     int default 0 not null,
    meso      int default 0 not null,
    constraint storages_ibfk_1
        foreign key (accountid) references accounts (id)
            on delete cascade
)
    charset = utf8;

create index accountid
    on storages (accountid);

INSERT INTO ms079.storages (storageid, accountid, slots, meso) VALUES (1, 1, 96, 0);