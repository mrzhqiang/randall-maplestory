create table skills_cooldowns
(
    id        int auto_increment
        primary key,
    charid    int             not null,
    SkillID   int             not null,
    length    bigint          not null,
    StartTime bigint unsigned not null
)
    engine = MyISAM
    charset = utf8;

