create table macbans
(
    macbanid int unsigned auto_increment
        primary key,
    mac      varchar(30) not null,
    constraint mac_2
        unique (mac)
)
    engine = MEMORY
    charset = utf8;

