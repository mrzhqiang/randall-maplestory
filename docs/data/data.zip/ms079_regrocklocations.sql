create table regrocklocations
(
    trockid     int auto_increment
        primary key,
    characterid int null,
    mapid       int null
)
    engine = MyISAM
    charset = utf8;

INSERT INTO ms079.regrocklocations (trockid, characterid, mapid) VALUES (1838, 12, 106021402);
INSERT INTO ms079.regrocklocations (trockid, characterid, mapid) VALUES (1837, 12, 106020000);
INSERT INTO ms079.regrocklocations (trockid, characterid, mapid) VALUES (1836, 12, 105070001);
INSERT INTO ms079.regrocklocations (trockid, characterid, mapid) VALUES (1835, 12, 101020001);