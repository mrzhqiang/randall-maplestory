create definer = root@`%` view readable_cheatlog as
select `a`.`name`             AS `accountname`,
       `a`.`id`               AS `accountid`,
       `c`.`name`             AS `name`,
       `c`.`id`               AS `characterid`,
       `cl`.`offense`         AS `offense`,
       `cl`.`count`           AS `count`,
       `cl`.`lastoffensetime` AS `lastoffensetime`,
       `cl`.`param`           AS `param`
from ((`ms079`.`cheatlog` `cl` join `ms079`.`characters` `c`)
         join `ms079`.`accounts` `a`)
where ((`cl`.`id` = `c`.`id`) and (`a`.`id` = `c`.`accountid`) and (`a`.`banned` = 0));

