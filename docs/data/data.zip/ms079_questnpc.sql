create table questnpc
(
    id     int auto_increment
        primary key,
    npcid  int                         null,
    itemid int                         null,
    sl     int default 0               null,
    zt     int                         null,
    name   varchar(128) charset gb2312 null,
    item   int                         null,
    itemsl int                         null,
    money  int                         null
)
    engine = MyISAM
    charset = latin1;

