create table dueypackages
(
    PackageId  int unsigned auto_increment
        primary key,
    RecieverId int(10)                       not null,
    SenderName varchar(15)                   not null,
    Mesos      int unsigned        default 0 null,
    TimeStamp  bigint unsigned               null,
    Checked    tinyint(1) unsigned default 1 null,
    Type       tinyint(1) unsigned           not null
)
    charset = utf8;

