create table fishingjf
(
    id      int auto_increment
        primary key,
    accname varchar(25) default '' not null,
    fishing int         default 0  not null,
    XX      int         default 0  not null,
    XXX     int         default 0  not null
)
    charset = latin1;

create index accname
    on fishingjf (accname);

INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (1, 'woaiwu545', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (2, 'ao6227889', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (3, 'zxczxc', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (4, 'iris_joker', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (5, 'qaz159357a', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (6, '312224299', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (7, 'a124465185', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (8, 'a361253212', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (9, 'm110425', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (10, 'www12345', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (11, 'Xinger', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (12, 'zhaozixie', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (13, '17664010826', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (14, 'mxdv079', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (15, 'qq111111', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (16, 'denghaha3', 0, 0, 0);
INSERT INTO ms079.fishingjf (id, accname, fishing, XX, XXX) VALUES (17, 'admin', 0, 0, 0);