create table bbs_threads
(
    threadid      int unsigned auto_increment
        primary key,
    postercid     int unsigned           not null,
    name          varchar(26) default '' not null,
    timestamp     bigint unsigned        not null,
    icon          smallint unsigned      not null,
    startpost     text                   not null,
    guildid       int unsigned           not null,
    localthreadid int unsigned           not null
)
    engine = MyISAM
    charset = utf8;

